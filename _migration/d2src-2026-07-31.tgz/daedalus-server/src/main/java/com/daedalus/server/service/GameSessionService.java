// SPDX-License-Identifier: MIT

package com.daedalus.server.service;

import com.daedalus.engine.MazeGrid;
import com.daedalus.model.GameSession;
import com.daedalus.model.LeaderboardEntry;
import com.daedalus.model.Point;
import com.daedalus.plugin.events.PlayerMovedEvent;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.util.UUID;


/** Active game sessions: open, move, complete. */
@Service
public class GameSessionService {

    private final ApplicationEventPublisher events;
    private final LeaderboardService leaderboard;
    private final boolean multiplayer;
    private final Cache<UUID, GameSession> sessions;

    /** Single-player service (multiplayer flag off) — the pre-flag behavior, kept for tests. */
    public GameSessionService(ApplicationEventPublisher events, LeaderboardService leaderboard) {
        this(events, leaderboard, false);
    }

    /** Default session-store bounds — see the five-arg constructor. */
    public GameSessionService(ApplicationEventPublisher events,
                              LeaderboardService leaderboard,
                              boolean multiplayer) {
        this(events, leaderboard, multiplayer, 10_000, Duration.ofHours(2));
    }

    /**
     * @param multiplayer the {@code daedalus.session.multiplayer} feature flag (BACKLOG stretch
     *                    goal, default {@code false}): when on, {@link #join} admits additional
     *                    named players into an existing session. Off, sessions behave exactly
     *                    as before the flag existed.
     * @param maxSessions bound on live sessions
     * @param idleTtl     eviction after inactivity. Sessions previously lived in an unbounded
     *                    {@code ConcurrentHashMap} and were never removed — not even after
     *                    completion — so every session ever opened stayed resident for the
     *                    life of the process. An evicted session simply answers 404 on its
     *                    next move, which is the API's existing "unknown session" path; the
     *                    idle TTL far outlives any game actually being played. Configurable
     *                    via {@code daedalus.session.*}.
     */
    @Autowired
    public GameSessionService(ApplicationEventPublisher events,
                              LeaderboardService leaderboard,
                              @Value("${daedalus.session.multiplayer:false}") boolean multiplayer,
                              @Value("${daedalus.session.max-sessions:10000}") long maxSessions,
                              @Value("${daedalus.session.idle-ttl:2h}") Duration idleTtl) {
        this.events = events;
        this.leaderboard = leaderboard;
        this.multiplayer = multiplayer;
        this.sessions = Caffeine.newBuilder()
                .maximumSize(maxSessions)
                .expireAfterAccess(idleTtl)
                .build();
    }

    /** Whether the {@code daedalus.session.multiplayer} flag is on. */
    public boolean multiplayerEnabled() { return multiplayer; }

    /** Opens an anonymous (unowned) session; see {@link #open(UUID, String, Point, String)}. */
    public GameSession open(UUID mazeId, String playerName, Point start) {
        return open(mazeId, playerName, start, null);
    }

    /**
     * @param owner verified subject from the caller's token, or {@code null} when the request
     *              carried no credentials. Recorded at open and immutable — this is what STOMP
     *              subscription authorization keys on (BACKLOG: per-destination rules).
     */
    public GameSession open(UUID mazeId, String playerName, Point start, String owner) {
        GameSession session = new GameSession(mazeId, playerName, start, owner);
        sessions.put(session.id(), session);
        return session;
    }

    public GameSession find(UUID id) { return sessions.getIfPresent(id); }

    /**
     * Adds a named player to an existing session (multiplayer flag only).
     *
     * @return the session on success; {@code null} when the flag is off, the session is
     *         unknown, or the session already completed. Joining under a name already present
     *         succeeds and keeps that player's current position — rejoin after a dropped
     *         connection must not teleport anyone back to start.
     */
    public GameSession join(UUID sessionId, String player, Point start) {
        if (!multiplayer) return null;
        GameSession s = sessions.getIfPresent(sessionId);
        if (s == null) return null;
        synchronized (s) {
            if (s.completed()) return null;
            s.join(player, start);
        }
        return s;
    }

    /**
     * Attempt a move; returns {@code false} for unknown/completed sessions and illegal steps.
     *
     * <p>The check-then-act sequence (read position, validate against the grid, write position)
     * is guarded by a per-session lock: {@code ConcurrentHashMap} protects the <em>map</em>, not
     * compound operations on one {@link GameSession}, and concurrent access to a single session
     * is realistic — two tabs, a reconnect race. Without the lock, two racing moves could both
     * validate against the same stale position and produce an illegal transition, a lost
     * {@code moveCount} increment, or a double completion (two leaderboard entries for one win).
     * The lock is per session, so distinct sessions never contend. Pinned by
     * {@code GameSessionServiceConcurrencyTest}; this guard becomes ownership-critical the
     * moment session-ownership modelling lands (TESTING.md, gap P3).
     */
    public boolean tryMove(UUID sessionId, MazeGrid grid, Point to) {
        return tryMove(sessionId, null, grid, to);
    }

    /**
     * Per-player variant: {@code player} names who is moving; {@code null} means the opening
     * player (the pre-multiplayer contract). A name that never joined is refused — a client
     * cannot conjure a player into a session by moving them.
     */
    public boolean tryMove(UUID sessionId, String player, MazeGrid grid, Point to) {
        GameSession s = sessions.getIfPresent(sessionId);
        if (s == null) return false;
        synchronized (s) {
            if (s.completed()) return false;
            String actor = (player == null) ? s.playerName() : player;
            Point from = s.playerPosition(actor);
            if (from == null) return false;
            // Only allow moves into open neighbors.
            if (!grid.openNeighbors(from).contains(to)) return false;
            s.move(actor, to);
            // Published inside the lock so events observe the same order the moves were
            // applied in — listeners were already invoked inline by publishEvent before
            // this lock existed, so no new reentrancy is introduced.
            //
            // What that costs, measured rather than assumed (21x21 maze, warmed): a move is
            // ~1.4us with no listeners and ~1.3us with traffic tracking on, i.e. the in-tree
            // listeners are free within noise. The cost that matters is any listener that
            // BLOCKS, because it blocks while holding this lock: a 60ms listener serialises
            // that session's next ten moves into 579ms. What makes that acceptable is the lock
            // being per session — a blocked listener cannot delay any other player, verified
            // in SessionLockIsolationTest, which is also the only thing standing between this
            // design and someone widening the lock. Widen it and one slow plugin queues the
            // whole server.
            //
            // Listeners are therefore on the request path by design. A listener that needs to
            // do slow or I/O-bound work should hand off to its own executor rather than
            // borrowing this thread.
            events.publishEvent(new PlayerMovedEvent(this, sessionId, actor, from, to));
            if (to.equals(grid.goal())) complete(s, grid);
            return true;
        }
    }

    private void complete(GameSession s, MazeGrid grid) {
        long elapsed = Duration.between(s.startedAt(), Instant.now()).toMillis();
        // Score formula ignores maze size for now; if size-normalized scoring
        // lands, the ideal-path baseline is grid.rows() + grid.cols().
        long score = Math.max(0, 100_000 - s.moveCount() * 10 - elapsed / 100);
        s.complete(score);
        leaderboard.submit(new LeaderboardEntry(
                s.id(), s.mazeId(), s.playerName(), score, s.moveCount(), elapsed,
                /* mazeGeneratorId */ "unknown", Instant.now()));
        // Inline like PlayerMovedEvent — listeners observe completion in move order.
        events.publishEvent(new com.daedalus.plugin.events.SessionCompletedEvent(this, s));
    }
}
