package com.daedalus;

import com.daedalus.desktop.DaedalusLauncher;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * Daedalus — pluggable maze engine.
 *
 * <p>Two boot modes:
 * <ul>
 *   <li>Headless backend (REST + WebSocket + plugin SPI) — run this class directly.</li>
 *   <li>JavaFX desktop client — run {@link DaedalusLauncher}, which boots Spring then launches the stage.</li>
 * </ul>
 */
@SpringBootApplication
@EnableAsync
public class DaedalusApp {

    private static ConfigurableApplicationContext context;

    public static void main(String[] args) {
        context = SpringApplication.run(DaedalusApp.class, args);
    }

    public static ConfigurableApplicationContext bootHeadless(String[] args) {
        if (context == null) {
            context = new SpringApplicationBuilder(DaedalusApp.class)
                    .headless(true)
                    .web(org.springframework.boot.WebApplicationType.SERVLET)
                    .run(args);
        }
        return context;
    }

    public static ConfigurableApplicationContext context() {
        return context;
    }

    /** Shim so DaedalusLauncher can boot Spring without owning the lifecycle. */
    static final class SpringApplicationBuilder extends org.springframework.boot.builder.SpringApplicationBuilder {
        SpringApplicationBuilder(Class<?>... sources) { super(sources); }
    }
}
